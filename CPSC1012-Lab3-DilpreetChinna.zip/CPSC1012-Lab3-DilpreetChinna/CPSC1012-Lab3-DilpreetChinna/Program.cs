﻿using System;
using System.Diagnostics.Contracts;

namespace CPSC1012_Lab3_DilpreetChinna
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Purpose:  Use looping structures, Construct repetitive code,Practice program maintenance
            //Input: Starting Balance, Interest Rate, NumberOfYears
            //Output: Compount Interest for every year
            //Written by: Dilpreet Chinna
            //Written for: Carlos Estay
            //Section: E01
            //Last Modified Date: 2022-10-22
            double balance = 0;
            Console.WriteLine("Starting Balance");
            double startingBalance = double.Parse(Console.ReadLine());

            Console.WriteLine("Interest Rate in %");
            double interestRate = double.Parse(Console.ReadLine());

            double interestRateInDecimal = interestRate / 100;

            Console.WriteLine("Number of Years");
            int numberOfYears = int.Parse(Console.ReadLine());

            double monthlyInterestRate = interestRateInDecimal / 12;

            for (int i = 0; i <= numberOfYears; i++)
            {
                balance = startingBalance * Math.Pow(1 + monthlyInterestRate, i * 12);
                balance = Math.Round(balance, 2);

                Console.WriteLine("Year: {0} ${1}", i, balance);
            }

        }
    }
}
